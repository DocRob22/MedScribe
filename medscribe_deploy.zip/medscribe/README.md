# MedScribe

Free documentation tools for nurses and healthcare providers.
Note prompts · SOAP scaffolds · ROS/PE builder · Prior auth letters

---

## Deploy in 2 minutes — pick one platform

### Option A — Vercel (recommended, fastest)

1. Go to [github.com](https://github.com) → New repository → name it `medscribe` → Create
2. Upload all files from this folder into the repo (drag and drop works)
3. Go to [vercel.com](https://vercel.com) → Sign up with GitHub → Add New Project
4. Select your `medscribe` repo → click **Deploy**
5. Vercel auto-detects Vite. Your live URL appears in ~60 seconds.
6. Optional: go to Project Settings → Domains → add `medscribe.vercel.app` as your custom name

Your link will be: `https://medscribe.vercel.app`

---

### Option B — Netlify (drag and drop, no GitHub needed)

1. Open a terminal in this folder and run:
   ```
   npm install
   npm run build
   ```
2. This creates a `dist/` folder
3. Go to [netlify.com](https://netlify.com) → Sign up free
4. Drag the `dist/` folder onto the Netlify deploy drop zone
5. Instant live URL — you can rename it under Site Settings → Domain

Your link will be: `https://[random-name].netlify.app`

---

### Option C — Replit (easiest, no install needed)

1. Go to [replit.com](https://replit.com) → Create Repl → select **React** template
2. Delete everything in the default files
3. Copy each file from this folder into the matching Replit file
4. Click **Run** — Replit builds and serves it automatically
5. Your live URL appears in the top of the browser panel

---

## Local development

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`

---

## Important: Anthropic API key

The Note Scaffold and Prior Auth tools call the Anthropic API.
In the current build the API calls go through Claude.ai's built-in proxy (works when opened inside Claude artifacts).

For your **live deployed site** you'll need to add your own API key:

1. Get a key at [console.anthropic.com](https://console.anthropic.com)
2. Create a `.env` file in the root of this project:
   ```
   VITE_ANTHROPIC_KEY=sk-ant-your-key-here
   ```
3. In `src/App.jsx`, find the two `fetch("https://api.anthropic.com/v1/messages"` calls
4. Add this header to each:
   ```js
   "x-api-key": import.meta.env.VITE_ANTHROPIC_KEY,
   "anthropic-version": "2023-06-01",
   "anthropic-dangerous-direct-browser-access": "true",
   ```
5. Redeploy

**Note:** For production with real users, move API calls to a small backend (Vercel serverless function, Supabase edge function) so your key stays private.

---

## Project structure

```
medscribe/
├── index.html          # HTML entry point
├── vite.config.js      # Vite config
├── package.json        # Dependencies
├── vercel.json         # Vercel deploy config
├── netlify.toml        # Netlify deploy config
├── public/
│   └── favicon.svg     # App icon
└── src/
    ├── main.jsx        # React entry point
    └── App.jsx         # Full MedScribe app
```

---

Built with React + Vite. Fonts: DM Sans + DM Mono.
